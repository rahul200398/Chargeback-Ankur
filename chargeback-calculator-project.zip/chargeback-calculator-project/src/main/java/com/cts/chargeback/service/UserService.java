package com.cts.chargeback.service;

import com.cts.chargeback.entity.User;

public interface UserService {
	void saveUser(User user);
	
	public User findUserDetails(String username);
}
