package com.cts.chargeback.dao;

import java.util.List;

import com.cts.chargeback.entity.ChargebackDetails;
import com.cts.chargeback.entity.Customer;

public interface CustomerDAO {
	
	public List<Customer> listAllCustomers();
	public List<Object[]> listAllChargeBacks();
	public List<ChargebackDetails> listAllTransactions(long accountNumber);
	public void savePayment(ChargebackDetails chargebackDetails);
	List<ChargebackDetails> listChargeBackTransactions(long accountNumber);

}
