package com.cts.chargeback.service;

import java.util.List;

import com.cts.chargeback.entity.ChargebackDetails;
import com.cts.chargeback.entity.Customer;

public interface CustomerService {
	
	public List<Customer> getCustomerList();
	
	public List<Object[]> getChargeBackDetailsList();
	
	public List<ChargebackDetails> getTransactions(long accountNumber);
	
	public void addPayment(ChargebackDetails chargebackDetails);
	
	public List<ChargebackDetails> getChargeBackTransactions(long accountNumber);

}
